package com.example.estudir;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String BANCO_DADOS = "Esdudir";
    private static int VERSAO = 2;

    public DatabaseHelper(Context context) {

        super(context, BANCO_DADOS, null, VERSAO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE curso (_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                "curso TEXT," +
                "modalidade TEXT);");

        db.execSQL("CREATE TABLE aluno (matricula INTEGER PRIMARY KEY NOT NULL," +
                "nome TEXT," +
                "curso_id INTEGER," +
                "FOREIGN KEY(curso_id) REFERENCES curso(_id));");

        db.execSQL("CREATE TABLE disciplina (_id INTEGER PRIMARY KEY," +
                "curso_id INTEGER," +
                "disciplina TEXT," +
                "FOREIGN KEY(curso_id) REFERENCES curso(_id));");

        db.execSQL("CREATE TABLE matricula (_id INTEGER PRIMARY KEY NOT NULL," +
                "curso_id INTEGER," +
                "aluno_id INTEGER," +
                "FOREIGN KEY(curso_id) REFERENCES disciplina(curso_id)," +
                "FOREIGN KEY(aluno_id) REFERENCES aluno(matricula));");

        db.execSQL("CREATE TABLE edirigido (_id INTEGER PRIMARY KEY," +
                "id_matricula INTEGER, etapa INTEGER, edirigido INTEGER," +
                "semanas INTEGER," +
                "FOREIGN KEY(id_matricula) REFERENCES matricula(_id));");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
            db.execSQL("DROP TABLE curso;");
            db.execSQL("CREATE TABLE curso (_id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                "curso TEXT," +
                "modalidade TEXT);");

    }


    public List<String> listarCursos() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT _id, curso FROM curso",null);
        List<String> cursos =  new ArrayList<String>();

        cursor.moveToFirst();

        for(int i=0; i < cursor.getCount();i++){
            cursos.add(cursor.getString(1));
            cursor.moveToNext();
        }

        cursor.close();
        return cursos;
    }



}
